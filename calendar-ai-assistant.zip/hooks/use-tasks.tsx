"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { v4 as uuidv4 } from "uuid"

export type Task = {
  id: string
  title: string
  description?: string
  date: string // ISO string
  completed: boolean
  assignment?: string // The parent assignment this task belongs to
}

type TasksContextType = {
  tasks: Task[]
  addTask: (task: Omit<Task, "id">) => void
  addTasks: (tasks: Omit<Task, "id">[]) => void
  updateTask: (id: string, updates: Partial<Omit<Task, "id">>) => void
  deleteTask: (id: string) => void
}

const TasksContext = createContext<TasksContextType | undefined>(undefined)

export function TasksProvider({ children }: { children: ReactNode }) {
  const [tasks, setTasks] = useState<Task[]>([])

  // Load tasks from localStorage on initial render
  useEffect(() => {
    const savedTasks = localStorage.getItem("calendar-tasks")
    if (savedTasks) {
      try {
        setTasks(JSON.parse(savedTasks))
      } catch (error) {
        console.error("Failed to parse saved tasks:", error)
      }
    }
  }, [])

  // Save tasks to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("calendar-tasks", JSON.stringify(tasks))
  }, [tasks])

  const addTask = (task: Omit<Task, "id">) => {
    const newTask: Task = {
      ...task,
      id: uuidv4(),
    }
    setTasks((prev) => [...prev, newTask])
  }

  const addTasks = (newTasks: Omit<Task, "id">[]) => {
    const tasksWithIds = newTasks.map((task) => ({
      ...task,
      id: uuidv4(),
    }))
    setTasks((prev) => [...prev, ...tasksWithIds])
  }

  const updateTask = (id: string, updates: Partial<Omit<Task, "id">>) => {
    setTasks((prev) => prev.map((task) => (task.id === id ? { ...task, ...updates } : task)))
  }

  const deleteTask = (id: string) => {
    setTasks((prev) => prev.filter((task) => task.id !== id))
  }

  return (
    <TasksContext.Provider value={{ tasks, addTask, addTasks, updateTask, deleteTask }}>
      {children}
    </TasksContext.Provider>
  )
}

export function useTasks() {
  const context = useContext(TasksContext)
  if (context === undefined) {
    throw new Error("useTasks must be used within a TasksProvider")
  }
  return context
}
