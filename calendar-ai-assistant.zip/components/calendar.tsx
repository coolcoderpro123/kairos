"use client"

import { useState } from "react"
import {
  format,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isSameMonth,
  isSameDay,
  addMonths,
  subMonths,
  parseISO,
  isToday,
} from "date-fns"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useTasks } from "@/hooks/use-tasks"
import { TaskDetails } from "@/components/task-details"

export function Calendar() {
  const [currentMonth, setCurrentMonth] = useState(new Date())
  const [selectedDate, setSelectedDate] = useState(new Date())
  const { tasks } = useTasks()
  const [showTaskDetails, setShowTaskDetails] = useState(false)

  const nextMonth = () => setCurrentMonth(addMonths(currentMonth, 1))
  const prevMonth = () => setCurrentMonth(subMonths(currentMonth, 1))

  const monthStart = startOfMonth(currentMonth)
  const monthEnd = endOfMonth(currentMonth)
  const monthDays = eachDayOfInterval({ start: monthStart, end: monthEnd })

  const daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

  const getTasksForDay = (day: Date) => {
    return tasks.filter((task) => {
      const taskDate = parseISO(task.date)
      return isSameDay(taskDate, day)
    })
  }

  const handleDateClick = (day: Date) => {
    setSelectedDate(day)
    setShowTaskDetails(true)
  }

  return (
    <Card className="shadow-md">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-bold">{format(currentMonth, "MMMM yyyy")}</CardTitle>
          <div className="flex space-x-2">
            <Button variant="outline" size="icon" onClick={prevMonth}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={nextMonth}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-7 gap-1 mb-2">
          {daysOfWeek.map((day) => (
            <div key={day} className="text-center font-medium text-sm py-2">
              {day}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {monthDays.map((day, i) => {
            const dayTasks = getTasksForDay(day)
            const isCurrentMonth = isSameMonth(day, currentMonth)
            const isSelected = isSameDay(day, selectedDate)
            const isTodayDate = isToday(day)

            return (
              <div
                key={i}
                className={`
                  min-h-[80px] p-1 border rounded-md cursor-pointer transition-colors
                  ${isCurrentMonth ? "bg-white" : "bg-gray-100 text-gray-400"}
                  ${isSelected ? "ring-2 ring-primary" : ""}
                  ${isTodayDate ? "bg-blue-50" : ""}
                `}
                onClick={() => handleDateClick(day)}
              >
                <div className="text-right p-1">
                  <span className={`text-sm ${isTodayDate ? "font-bold text-primary" : ""}`}>{format(day, "d")}</span>
                </div>
                <div className="space-y-1 mt-1">
                  {dayTasks.slice(0, 2).map((task, idx) => (
                    <Badge key={idx} variant="outline" className="text-xs truncate block">
                      {task.title}
                    </Badge>
                  ))}
                  {dayTasks.length > 2 && (
                    <Badge variant="secondary" className="text-xs">
                      +{dayTasks.length - 2} more
                    </Badge>
                  )}
                </div>
              </div>
            )
          })}
        </div>

        {showTaskDetails && <TaskDetails date={selectedDate} onClose={() => setShowTaskDetails(false)} />}
      </CardContent>
    </Card>
  )
}
