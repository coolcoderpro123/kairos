"use client"
import { format } from "date-fns"
import { X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { useTasks } from "@/hooks/use-tasks"
import { parseISO, isSameDay } from "date-fns"

interface TaskDetailsProps {
  date: Date
  onClose: () => void
}

export function TaskDetails({ date, onClose }: TaskDetailsProps) {
  const { tasks, updateTask } = useTasks()

  const tasksForDay = tasks.filter((task) => {
    const taskDate = parseISO(task.date)
    return isSameDay(taskDate, date)
  })

  const handleTaskComplete = (taskId: string, completed: boolean) => {
    updateTask(taskId, { completed })
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-xl font-bold">Tasks for {format(date, "MMMM d, yyyy")}</CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent>
          {tasksForDay.length === 0 ? (
            <p className="text-center text-gray-500 py-4">No tasks for this day</p>
          ) : (
            <ul className="space-y-3">
              {tasksForDay.map((task) => (
                <li key={task.id} className="flex items-start space-x-3 p-2 rounded hover:bg-gray-50">
                  <Checkbox
                    id={task.id}
                    checked={task.completed}
                    onCheckedChange={(checked) => handleTaskComplete(task.id, checked as boolean)}
                  />
                  <div className="flex-1">
                    <label
                      htmlFor={task.id}
                      className={`font-medium cursor-pointer ${task.completed ? "line-through text-gray-400" : ""}`}
                    >
                      {task.title}
                    </label>
                    {task.description && <p className="text-sm text-gray-500 mt-1">{task.description}</p>}
                    {task.assignment && <p className="text-xs text-blue-600 mt-1">Part of: {task.assignment}</p>}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
