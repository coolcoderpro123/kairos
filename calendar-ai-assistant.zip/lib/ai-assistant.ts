import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { addDays, format, parseISO, differenceInDays } from "date-fns"
import type { Task } from "@/hooks/use-tasks"

// Function to process an assignment and break it down into tasks
export async function processAssignment(userInput: string): Promise<{ response: string; tasks: Omit<Task, "id">[] }> {
  try {
    // Extract assignment details and deadline from user input
    const { assignmentName, deadline, description } = await extractAssignmentDetails(userInput)

    if (!assignmentName || !deadline) {
      return {
        response:
          "I couldn't understand the assignment details. Please provide the assignment name and deadline clearly. For example: 'I have a research paper on climate change due on May 15th'.",
        tasks: [],
      }
    }

    // Parse the deadline
    let deadlineDate: Date
    try {
      deadlineDate = parseISO(deadline)
    } catch (error) {
      return {
        response: "I couldn't understand the deadline format. Please provide a clear date like 'May 15, 2023'.",
        tasks: [],
      }
    }

    // Generate tasks for the assignment
    const tasks = await generateTasksForAssignment(assignmentName, description, deadlineDate)

    // Create response message
    const response = `I've added "${assignmentName}" to your calendar with a deadline of ${format(deadlineDate, "MMMM d, yyyy")}. I've broken it down into ${tasks.length} tasks spread out until the deadline. Check your calendar to see the daily tasks!`

    return { response, tasks }
  } catch (error) {
    console.error("Error processing assignment:", error)
    return {
      response:
        "I encountered an error while processing your assignment. Please try again with clearer details about your assignment and deadline.",
      tasks: [],
    }
  }
}

// Function to extract assignment details from user input
async function extractAssignmentDetails(
  userInput: string,
): Promise<{ assignmentName: string; deadline: string; description: string }> {
  const prompt = `
    Extract the following information from this text about an assignment:
    1. Assignment Name: The name or title of the assignment
    2. Deadline: The due date of the assignment (in YYYY-MM-DD format)
    3. Description: Any details about what the assignment involves
    
    Text: "${userInput}"
    
    Respond in JSON format like this:
    {
      "assignmentName": "...",
      "deadline": "YYYY-MM-DD",
      "description": "..."
    }
    
    If any information is missing, leave that field empty. Make your best guess for the deadline based on context.
  `

  try {
    // Use the OpenAI model with the API key from environment variables
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt,
    })

    // Parse the JSON response
    try {
      const parsedResponse = JSON.parse(text)
      return parsedResponse
    } catch (jsonError) {
      console.error("Error parsing JSON response:", jsonError)
      // Fallback to a basic extraction if JSON parsing fails
      return {
        assignmentName: userInput.split("due")[0]?.trim() || "Unnamed Assignment",
        deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0], // Default to 1 week from now
        description: userInput,
      }
    }
  } catch (error) {
    console.error("Error extracting assignment details:", error)
    return {
      assignmentName: "Unnamed Assignment",
      deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      description: userInput,
    }
  }
}

// Function to generate tasks for an assignment
async function generateTasksForAssignment(
  assignmentName: string,
  description: string,
  deadline: Date,
): Promise<Omit<Task, "id">[]> {
  const today = new Date()
  const daysUntilDeadline = Math.max(1, differenceInDays(deadline, today))

  // For very short deadlines, we need to create fewer tasks
  const numberOfTasks = Math.min(10, Math.max(3, daysUntilDeadline))

  const prompt = `
    Create a task breakdown for completing this assignment:
    
    Assignment: ${assignmentName}
    Description: ${description}
    Deadline: ${format(deadline, "MMMM d, yyyy")}
    Days available: ${daysUntilDeadline}
    
    Create exactly ${numberOfTasks} tasks that would help complete this assignment on time.
    For each task, provide:
    1. A clear, specific title
    2. A brief description of what needs to be done
    3. When it should be completed (distribute evenly across the available days)
    
    Respond in JSON format like this:
    [
      {
        "title": "Task title",
        "description": "Task description",
        "dayOffset": 0 // 0 means today, 1 means tomorrow, etc.
      }
    ]
    
    Make sure the tasks are specific, actionable, and appropriate for the assignment type.
    Distribute the tasks evenly across the available days, with more intensive tasks earlier if possible.
  `

  try {
    // Use the OpenAI model with the API key from environment variables
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt,
    })

    // Parse the JSON response
    try {
      const tasksList = JSON.parse(text)

      // Convert to our Task format
      return tasksList.map((task: any) => {
        const taskDate = addDays(today, task.dayOffset)
        return {
          title: task.title,
          description: task.description,
          date: format(taskDate, "yyyy-MM-dd"),
          completed: false,
          assignment: assignmentName,
        }
      })
    } catch (jsonError) {
      console.error("Error parsing JSON tasks:", jsonError)
      // Fallback to creating basic tasks if JSON parsing fails
      return createFallbackTasks(assignmentName, daysUntilDeadline)
    }
  } catch (error) {
    console.error("Error generating tasks:", error)
    return createFallbackTasks(assignmentName, daysUntilDeadline)
  }
}

// Create fallback tasks if the AI generation fails
function createFallbackTasks(assignmentName: string, daysUntilDeadline: number): Omit<Task, "id">[] {
  const today = new Date()
  const numberOfTasks = Math.min(5, Math.max(3, daysUntilDeadline))
  const tasks: Omit<Task, "id">[] = []

  const defaultTasks = [
    { title: "Research", description: "Gather information and resources" },
    { title: "Plan", description: "Create an outline or plan" },
    { title: "Draft", description: "Create a first draft" },
    { title: "Review", description: "Review and revise" },
    { title: "Finalize", description: "Complete final version" },
  ]

  // Distribute tasks evenly
  for (let i = 0; i < numberOfTasks; i++) {
    const dayOffset = Math.floor((i * daysUntilDeadline) / numberOfTasks)
    const taskDate = addDays(today, dayOffset)

    tasks.push({
      title: defaultTasks[i % defaultTasks.length].title,
      description: defaultTasks[i % defaultTasks.length].description,
      date: format(taskDate, "yyyy-MM-dd"),
      completed: false,
      assignment: assignmentName,
    })
  }

  return tasks
}
