import { Calendar } from "@/components/calendar"
import { ChatBox } from "@/components/chat-box"

export default function Home() {
  return (
    <main className="min-h-screen p-4 md:p-8 bg-gray-50">
      <div className="max-w-7xl mx-auto space-y-8">
        <header className="text-center py-6">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800">Smart Calendar Assistant</h1>
          <p className="text-gray-600 mt-2">Enter your assignments and let AI help you plan your schedule</p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Calendar />
          </div>
          <div className="lg:col-span-1">
            <ChatBox />
          </div>
        </div>
      </div>
    </main>
  )
}
